eplay_package_v2.0

This package will play the wurlitzer e-rolls for style 125, 150 and 165 band organs
in my Wurlitzer e-roll archive. The organs are fully instrumented and activated
so stops, shutters, bells and percussion are all fully functional.

Midimusic e-rolls are type 0 midi tracker bar image files with hole 1 = midi note 24.

Other e-roll formats including AMI format can be converted to my Midimusic e-roll
format using MIDIREPL. A midi editor may also be needed.

You must use the appropriate .exe file for each organ style. For now they work only in
a Windows DOS command window. Programming for the Windows graphic environment is for
me much more difficult than programming Android apps.

Use eplay125 for style 125 e-rolls.
Use eplay150 for style 150 e-rolls.
Use eplay165 for style 165 e-rolls.

This 32 bit package will work on 32 or 64 bit Windows operating systems.
It was designed and tested using Windows 8.1 but will work on earlier versions
including Windows XP.

To install the package simply copy all the files to a folder of your choice,
ideally a folder on your PATH. If you want, as I do, to make a clean installation
and you have administrator rights you can use the control panel to add the folder of
your choice to the PATH.

To uninstall the package simply delete the files. The package does not use the
Windows Registry.

The use of Rich Olsen's sound font has got rid of all the sound quality problems
of my previous package. I have included my version of his font in this package and
the improvement in sound quality and accuracy of the Organ Simulations is immense.
If you connect a good hi-fi system to your computer the sound will probably be better
than you would get from a real organ, mainly because the tuning is perfect and there
is no mechanical noise.

David Back April 2015.








