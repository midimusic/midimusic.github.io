How to install eplayWin32. Version 3_1c

1. IMPORTANT If you have a previous installation of eplayWin32 and
have either altered the stop settings or added other organs you may
wish to save a backup of your eplay.ini file in a safe place before
uninstalling. Location:-
c:\Program Files\eplay\eplay.ini for 32 bit windows systems or
c:\Program Files (x86)\eplay\eplay.ini for 64 bit windows systems.
Note: eplayWin32V3_1c will run with eplayWin32V3_1, eplayWin32V3_1a
or eplayWin32V3_1b eplay.ini files but will not run with older
eplay.ini files.

2. Install eplayWin32

2.1. Windows - Run the eplay setup program setup_eplayWin32V3_1c.exe
Alternatively you can simply do a manual install by copying the folder
eplayWin32 and its files to a location of your choice.

2.2. iMac - To run under wine - If necessary download and install wine.
Copy the folder eplayWin32 and its files to a location of your choice.
You can make an alias (shortcut) of eplayWin32.exe and keep it on your desktop.
To run eplayWin32 just double click the .exe or its alias. It will start up and
run just as it does on Windows. Alternatively you can run the setup program.

2.3. Linux - Same as iMac above or you can install it as in Windows above
after wine has been installed.

4. OPTIONAL You may wish to transfer some of your old backed up eplay.ini
settings to the new eplay.ini settings provided with this copy of eplayWin32.
Be careful mistakes can easily prevent the program functioning correctly. Use
the menus to make changes - not direct editing. You cannot directly use an
old eplay.ini prior to Version 3.1 with this version of eplayWin32.

David Back April 2017
