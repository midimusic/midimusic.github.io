How to install eplayWin32. Version 2.15c

1. IMPORTANT If you have a previous installation of eplayWin32 and
have either altered the stop settings or added other organs you may
wish to save a backup of your eplay.ini file in a safe place before
uninstalling. Location:-
c:\Program Files\eplay\eplay.ini for 32 bit windows systems or
c:\Program Files (x86)\eplay\eplay.ini for 64 bit windows systems.
Note: eplayWin32V2.15 will not run with old elpay.ini files.

2. Install eplayWin32

2.1. Windows - Use the control panel to uninstall any previous version
of eplayWin32 as the installer will not install a new version over the
top of an old version. Run the eplay setup program setup_eplayWin32V2_15c.exe
Alternatively you can simply do a manual install by copying the folder
eplayWin32 and its files to a location of your choice.

2.2. iMac - To run under wine - If necessary download and install wine.
Copy the folder eplayWin32 and its files to a location of your choice.
You can make an alias (shortcut) of eplayWin32.exe and keep it on your desktop.
To run eplayWin32 just double click the .exe or its alias. It will start up and
run just as it does on Windows.

2.3. Linux - Same as iMac above.

4. OPTIONAL You may wish to transfer some of your old backup settings
to the new settings provided with this copy of eplayWin32. Be careful
mistakes can easily prevent the program functioning correctly. Use the
menus to make changes - not direct editing. You cannot directly use an
eplay.ini prior to V2.15 with this version of eplayWin32.

David Back April 2016
