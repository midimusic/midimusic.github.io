Installing eplay into an iMac

I believe this package contains all you need to install eplay into
an iMac (i.e. a Mac with a 64 bit Intel processor).

Unfortunately I have not yet discovered how to make the iMac play
e-rolls just by double clicking on them like the Windows version of
eplay does. It should and I will update the package when I have made
it work.

However all four eplays do work OK from the command line once they
have been installed.

In the meantime to play e-rolls
1) Open a Terminal
2) Type the command
3) Type a space
4) Drag and drop an e-roll file on to the Terminal Window
5) Type carriage return to begin playing

This package was developed on an iMac using Yosemite operating system.
I suspect it will work on older systems but have not tested it.

Also, as I have access to only the one iMac, which is no longer new,
I cannot check for sure that I have included every library file which
would be needed by a brand new system. If you get an error message
saying eplay needs a library file which is not installed on your system
please email me (email address is in "About Midimusic") and I will send
you the file/s that you need and update the package accordingly.

To install the package:

1) Using Finder unzip all the files into a new folder somewhere in your
 home folder. Note that the sound font .sf2 files are necessary and are
 in a separate download.

2) Open a Terminal, cd to the new folder you created above and type
 ./install_eplay
 All the files and libraries will then be copied to their necessary
 destinations. If any of the files already exist on your computer a
 backup copy will be made in the destination folder with the
 extension .old

 eplay also needs some system files in /usr/lib these will probably be
 already installed - if so no action is needed. However if one or more
 is missing install_eplay will tell you and you will have to run it again
 with Administrator privileges.

3) Open a new terminal and type
 eplay125mac
 eplay125mac should open, give a message and close again. If there is no
 error message all is probably well.

4) From the command line tell eplay125mac to play a w125 e-roll. If it
 plays without errors then all is OK and all the eplays should work.

David Back July 2015.
