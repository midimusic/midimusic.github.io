eplayOrgan64v4.2.3-2 May 2023

1. General

EplayOrgan is a multi purpose virtual pipe organ intended to
be playable by organists. It will load and be playable almost instantly
and does not need an expensive computer with huge amounts of memory.

Version 4 and greater of eplayOrgan use fluidsynth version 2. For the 64 bit
versions of eplayOrgan much larger memory is available and this
can acconmmodate much larger .sf2 and .sf3 sound fonts. Such fonts can
give higher sound quality, comparable with that of GrandOrgue and Hauptwerk
organs. Other features remain largely unaltered.

Version 4.2.3 responds to standard non real time midi tuning dumps. These
dumps must be in a midi file and will automatically tune the organ when played
or just dropped on to the organ. Some sample dumps from Scala are included.
Also a few bugs in the midi file player and recorder have been removed.
In version 4.2.3-2 the universal organ sound font has been carefully re-tuned
and notes are A=440 equal tempered and within a tolerance of +-2 cents.

Version 4.2.2 responds to standard real time midi tuning sysex. It can be
tuned to any temperament using on line tuning apps such as Plainsound Hexatone.
It can make midi tuning files and record and play midi files with the
correct temperament. It can still be played with standard midi keyboards though
if you are ambitious you could try a Lumatone or similar microtonal keyboard.

Version 4.2.1 has improved midi "end of file" accuracy. Remote control and
automatic filename generation for recording midi files. Unused manuals and
pistons are no longer displayed. The handbook now has details of the midi
sysex codes used by LCD and auto record functions.

Version 4.2.0.4 has implemented the full capability of midi "tempo" events
such as are used copiously in midi files exported by Musescore. This version
displays the full time/tempo map and always plays at the correct tempo.
It also displays the current tempo whilst playing a midi file. You must make
sure that the midi channels in exported midi files match those of the organ
you wish to play. Also note that program changes in midi files will activate
the organ's pistons - use this to advantage by using them to set stops.
Always set the MuseScore synthesizer to output CC11's in order to operate
swell pedals before exporting a midi file. Time and Key Signatures are now
displayed by eplayOrgan along with the time they were changed.

Vesrion 4.2 has a re-designed menu system which separates the organ playing
menus from those used by the organ designer. This makes the menus easier
to follow. There are also visual improvements to the organ's graphic
user interface and other internal improvements.

Version 4.1 has a purpose designed Universal sound font which
uses the best free organ samples I can find and uses real relase samples
instead of that dreadful fake reverb. many organs still use. The one
font is compatible with all theatre and church organs. For details see
Help Appendix 4.

In order to keep the new font small enough to supply with the eplayOrgan
download it has less samples per octave than the very best samplesets but
it still loads very quickly and sounds good to me. All the samples can be
extended by users if they wish.

Nearly all organs have their own unique midi format. There is no
standardisation for midi channels, stops or expression controls.
Thus an organ midi file will seldom if ever play properly a different organ.
Version 3 and later of eplayOrgan allows you to automatically and in real
time translate and play almost any organ midi file on another organ. No other
organ can do this.

Translation is a two stage process, first the file is translated to an
intermediate, Universal organ format and then translated again to play on the
target organ. You can either record the intermediate file and play it later on
the target organ or you can route it to the target organ via a real or virtual
midi cable for immediate playing. For stops which do not exist on the target
organ a "Virtual Organist" will automatically select alternatives. You can also
adjust stops by hand while your translated organ is being recorded.

The midi file player includes the latest ideas on how to accurately play
a midi file. A multi track midi file has to necessarily have its midi events
sorted into time order before it can be played. This process used to have the
problem that events occuring at exactly the same time could get out of order.
This lack of order sometimes generated "note on" events without any
corresponding "note off" event potentially generating a cipher (continuously
playing note). This used to be avoided by checking that every "note on" event had
a corresponding "note off" event before allowing the note to play. This check
is no longer needed and the result is 100% accurate playing of all midi files
and the improvement is well worthwhile.

Velocity sensitivity may be applied to any rank, or even the entire organ.

You can export and import organs, this is useful for sharing and adding new
organs. Hauptwerk's sysex format for stop selection and LCD display is now
supported.

Hauptwerk midi file formats are supported. Stops may be selected using
midi sysex events as well as nrpn events and master couplers may be used. Both
will be recorded and played, as appropriate, in midi files.

Version 3.0k Viscount trems corrected. Allen trems corrected. Midi translation improved
for invalid stops. Virtual organist improved.

Version 3.1 Pistons have been improved. There are now 4 banks of pistons and you can
save and load piston files. Each piston file contains all 4 banks. Pistons are
separate for each organ - there is no interaction between organs. In version 3.1.0.1
there is now a piston stepper which makes piston setting easier whilst playing.
See Help Appendix 3 for details.

All GrandOrgue organs are supported - eplayOrgan can read, write and play midi files
in Grande Orgue's GO SMPTE format.

It is possible to play Wurlitzer and Estey e-rolls directly (i.e. without the need
for eplayWin32). The File/Open.. dialog allows selection of .mid, mes, .m25, m50
and .m65 files. All these files are immediately playable if a suitable organ has been
selected. Estey .mes files can be played on any normal organ provided its pistons have
been set up. These piston settings are described in Help/APPENDIX 2. The pistons of some
organ are already set up to play Estey e-rolls. If you want to keep
these settings then save the pistons to a file before changing the piston settings. You
can then reload the Estey settings whenever you need them.

Version 3.2 Tremolo is fully implemrented - previously the stops worked but did not
do anything. Now Tremolo stops activate the tremolo time delay, modulation and vibrato
oscillators built into the sound fonts. This produces tremolo - the amount and frequency
is defined by defaults or variables in the .sf2 sound fonts. Tremolo amplitude can be
adjusted to taste by adjusting "Tremolo:" in Options../Edit Organ.. menu.

This version also has optional Autobass. The lowest note below midi 61 (middle C#) on
great is repeated in the pedal division. Autobass is normally turned off. A tick box
on the main window will turn it on if it is required.

Swell pedal response includes automatic adjustment to provide loss of higher
frequencies as the swell shutters close. This simulates what happens on a real organ.

There is now also an option to transpose keyboard inputs by -11 to +11 semitones.

Playlist functions and useability have been improved.

From this version Grande Orgue midi files can be read, written and played.
Note that you must import an appropriate settings file e.g. GOdemoV1ToSelf.cmb into
GO before the files will play correctly. (Save your normal settings before
doing this - you can then restore your normal settings later.)

Versions 3.3.0.0 and later allow stop numbers to include stop 0 and accommodate less
than four sound fonts. This is needed for some GO organs and required a lot of internal
changes. Also the midi file player can now correctly play all SMPTE coded files.

2. Installation

eplayOrgan64 will install and run on almost any computer using 64 bit Windows.
It will also install and run correctly on 64 bit Linux or Mac computers but for this
you will first need to install Wine. See the READMEFIRST.txt file for
installation details.

3. Using eplayOrgan64

Double click eplayOrgan64.exe or the alias (shortcut) on your desktop,
eplayOrgan will open its window. Click on the "Options" menu and
select "Setup". Select the organ you wish to play.

Use the Help menu for details.

You are likely to need a touch screen monitor for selecting stops
while playing, but your mouse will work at other times. If you plan to
use the "Stops Input" your hardware will need to supply the stops and
expression controls as Universal NRPN's and controls as this enables one
source to be translated and service the needs of all the different organs.

A minimum of one midi keyboard will be needed, midi keyboard channels
are set up automatically. Most midi keyboards will be able to provide the midi
program change messages required to select pistons and control change messages
required to set Swell and Volume levels. (Ref. Appendix 3) Use midi to USB
adaptors to connect your keyboards and pedals. Try to get your adaptors all
from different makers so that they all have different names. The name is the
only means of identifying one from the other and cannot be altered.

If you are a proper organist you will also need some midified organ pedals
and a few other bits of woodwork to hold it all together.

If you already have an organ console with one multichannel midi output
then connect it to Universal Input. Set up the console channels and swells to
work with the "Universal Organ". This console will then work with all the organs
without any further setting up. Stops use the Universal NRPN format.
You can also use this input for remote controls. (Ref. Appendix 1)

To get the best out of the organs you will need to connect at least
one good quality hi-fi amplifier and speakers. These organs can produce
very low notes (down to 16Hz) at high amplitude - just like a real organ. There
are up to four stereo outputs if you want more realism.

6. Notes

The Blanchet-1720.sf2 harpsichord sampleset can be obtained free from
Sony Musicae at http://duphly.free.fr/en/blanchet.html.

Many other sf2 and sf3 sound fonts are available and all of them will work
with eplayOrgan64. Use 64 bit Polyphone to make new fonts or to edit them.

Latency of eplayOrgan is negligable when it is used on
a Windows system but on the iMac and Linux latency may a bit marginal
for comfortable playing from keyboards.

Hundreds of midi files playable on the various organs can be found on
line. As a starting point try the links to websites listed in "Help".
You can also play all the midi files and e-rolls in my archives.
There are many thousands of midified piano rolls available on line.
With a bit of work these can be filtered and edited to play on an organ.
Autobass will help here.

I would like to hear of any problems found by organists who have
played eplayOrgan. I will cure problems and issue updates as necessary.

David Back Contact details are in "About" on my website
https://midimusic.github.io

