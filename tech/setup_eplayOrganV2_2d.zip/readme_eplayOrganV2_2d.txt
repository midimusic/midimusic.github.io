eplayOrgan V2.2d July 2018

1. General

EplayOrgan is a brand new multi purpose pipe organ simulator intended to
be playable by organists. It will load and be playable almost instantly
and does not need an expensive computer with huge amounts of memory.

The midi file player includes the latest ideas on how to accurately play
a midi file. A multi track midi file has to necessarily have its midi events
sorted into time order before it can be played. This process used to have the
problem that events occuring at exactly the same time could get out of order.
This lack of order sometimes (but rarely) generated "note on" events without
any corresponding "note off" event potentially generating a cipher (continuously
playing note). This used to be avoided by checking that every "note on" event had
a corresponding "note off" event before allowing the note to play.

The result is 100% accurate playing of all midi files and the improvement
is well worthwhile.

Velocity sensitivity may be applied to any rank, or even the entire organ.

2. Installation

For running eplayOrgan on Mac or Linux computers you will first need
to install Wine. See the READMEFIRST.txt file for installation details.

3. Using eplayOrgan

Double click eplayOrgan.exe or the alias (shortcut) on your desktop,
eplayOrgan will open its window. Click on the "Options" menu and
select "Setup". Select the organ you wish to play.

Use the Help menu for details.

You are likely to need a touch screen monitor for selecting stops
while playing, but your mouse will work at other times. A minimum
of one midi keyboard will be needed, midi keyboard channels are set
up automatically. Most midi keyboards will be able to provide the midi
program change messages required to select pistons. If you are a proper
organist you will also need some midified organ pedals and a few other
bits of woodwork to hold it all together.

To get the best out of the organs you will need to connect at least
one good quality hi-fi amplifier and speakers. These organs can produce
very low notes at high amplitude - just like a real organ. There are
up to four stereo outputs if you want more realism.

6. Notes

The Burea Church sound font Burea_Church_Ext_2.02.sf2 is associated
with jOrgan and can currently be downloaded from:
http://familjenpalo.se/vpo/sf2

Many other sf2 sound fonts are available and all of them will work
with eplayOrgan, use Viena to edit them if necessary.

EplayOrgan can be played from any midi keyboards or a full midified
organ console. Latency of eplayOrgan is negligable when it is used on
a Windows system but on the iMac and Linux latency may a bit marginal
for comfortable playing from keyboards.

Please contact me if you require assistance to program eplayOrgan
to play other organs.

I would like to hear of any problems found by organists who have
played eplayOrgan. I will cure problems and issue updates as necessary.

David Back July 2018. Contact details are in "About" on my website
https://midimusic.github.io

