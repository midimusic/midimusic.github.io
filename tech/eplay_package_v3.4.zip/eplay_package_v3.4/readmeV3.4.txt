eplay_package_v3.4  Minor correction inserted 29/11/2015.

This package will play the wurlitzer e-rolls for style 125, 150 and 165 band organs
in my Wurlitzer e-roll archive and all Estey e-rolls in my Estey e-roll archive.

The only change from eplay_package_v3.3 is an update of eplayestey. Pedal presets
have been added to eplayestey so that stage 1 and 2 new music play the correct
pedal presets.

A purpose designed, properly instrumented set of soundfonts is now provided for
eplayestey. The improvement is immense, particularly for stage 1 and 2 new music as
these fonts are the first to play the correct presets for all stop combinations. 

The organs are fully instrumented and activated so stops, shutters, bells and percussion
are all fully functional.

Wurlitzer e-rolls are type 0 midi tracker bar image files with hole 1 = midi note 24.
Estey e-rolls are type 0 midi tracker bar image files with hole 1 = midi note 1.

Other e-roll formats including AMI format can be converted to my Midimusic e-roll
formats using MIDIREPL.EXE and MIDI1TO0.EXE. A midi editor may also be needed.
 
This 32 bit package will work on 32 or 64 bit Windows operating systems.
It was designed and tested using Windows 8.1 but will work on earlier versions
including Windows XP. It also works on Windows 10.

1 - First Time Installation

The aim of this installation is to set up your system so that by double clicking on
any e-roll, anywhere on your system:

1) A DOS command window will automatically open.
2) The music will play
3) When finished the DOS command window will automatically close.

To install the package make a new folder C:\eplay, extract and copy all the files to this folder.

IMPORTANT NOTE: All the sound fonts now have to be downloaded in a separate package. Extract
the fonts and add them to the folder C:\eplay.

Now, using the Windows Control Panel you must add C:\eplay to your PATH.
Details below are for Windows 8/8.1 but are similar for any version of windows.

1) Using the CHARMS bar search for PATH and select "Edit the system environment variables"
2) Enter your administrative password and a "System Properties" dialog will open.
3) Select the "Environment Variables" button and an "Environment Variables" dialog will open.
4) Look in System variables and find Path, click on this and select Edit...
5) Another small dialog will open "Edit System Variable".
6) Click on Variable value and use arrow buttons to move the vertical pointer to the end of
   the long string (VERY IMPORTANT: Make sure there is a white background, NOT a blue one)
7) Type ";C:\eplay" without the quotes. (omitted ":" added 29/11/2105)
8) Click OK and OK your way back to the point where all dialogs have gone.

You can verify your work by opening a DOS command window and typing PATH. A long string
will be displayed which should end with ;C:\eplay - if it does not, re-check the above steps.

In order that the correct playing program is started for each type of e-roll and to prevent
the system from confusing e-rolls with normal midi files I recommend that you use the
extensions .m25, .m50 and .m65 for style 125, 150 and 165 rolls respectively. Use .mes
extension for Estey e-rolls.

Now find a style 125 e-roll with the extension .m25 and double click it, follow the dialogs
and tell windows you want to play this file with C:\eplay\eplay125.exe

Repeat for a style 150 e-roll with the extension .m50 to play with C:\eplay\eplay150.exe
and a style 165 e-roll with the extension .m65 to play with C:\eplay\eplay165.exe

Repeat for an Estey e-roll with the extension .mes to play with c:\eplay\eplayestey.exe

Now when you double click any e-roll anywhere it will automatically play.

2 - Update a previous installation of eplay

If you have already successfully installed an earlier eplay package for Wurlitzer organs
you can add or update the Estey organ player just by copying the new files eplayestey.exe,
201509esteyDB0-0.sf2 and 201509esteyDB1-0.sf2 to the c:\eplay folder. If you have not done it
already; double click on an Estey e-roll with the extension .mes follow the dialogs and
tell windows you want to play it using c:\eplay\eplayestey.exe

3 - Uninstallation

To uninstall the package delete C:\eplay from your path (reverse of the process above)
and then delete the files and folder. The package itself does not use the Windows Registry.

4 - Sound Quality and Organ Simulation

If you connect a good hi-fi system to your computer the sound will probably be better
than you would get from a real organ, mainly because all notes play with perfect tuning
and there is no mechanical noise.

I plan to continue work to further improve the estey soundfonts. In particular I will be
checking the tuning of every note of every instrument and adjusting it if necessary.

David Back October 2015.








