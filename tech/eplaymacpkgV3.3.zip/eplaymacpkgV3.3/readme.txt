eplaymac package version 3.3

This package will play the wurlitzer e-rolls for style 125, 150 and 165 band organs
in my Wurlitzer e-roll archive and all Estey e-rolls in my Estey e-roll archive.

The only change from eplaymacpkgV3.1 is an update of eplayestey. Eplayestey now
detects the "New Music" Stage of each e-roll it plays and uses two sound fonts - one
for the original e-rolls and another for New Music stages 1 and 2. It also plays
New Music stage 2 rolls but does not use the additional features that stage 2
could provide because there is currently no information available which details them.
I have also slightly increased the fluidsynth gain so that the output volume level
is similar to the other eplays.

The organs are fully instrumented and activated so stops, shutters, bells and percussion
are all fully functional.

Wurlitzer e-rolls are type 0 midi tracker bar image files with hole 1 = midi note 24.
Estey e-rolls are type 0 midi tracker bar image files with hole 1 = midi note 1.

Other e-roll formats including AMI format can be converted to my Midimusic e-roll
formats using MIDIREPL.EXE and MIDI1TO0.EXE. A midi editor may also be needed.

I believe this package contains all you need to install eplay into
an iMac (i.e. a Mac with a 64 bit Intel processor).

Once the package has been installed you will be able to play any
e-roll anywhere on your system just by double clicking it.

Alternatively you can drag and drop any e-roll on to eplayScript2.app
and the e-roll will play. You will find it on the Launchpad - with its
yellow MM icon. You may find it convenient to add a copy to the Dock
or just copy and paste a copy on to your Desktop.

In both cases a window will open, the music will play and when finished
the window will close.

This package was developed on an iMac using Yosemite operating system.
I suspect it will work on older systems but have not tested it.

Also, as I have access to only the one iMac, which is no longer new,
I cannot check for sure that I have included every library file which
would be needed by a brand new system. If you get an error message
saying eplay needs a library file which is not installed on your system
please email me (email address is in "About Midimusic") and I will send
you the file/s that you need and update the package accordingly.

First Time Installation:

1) Using Finder unzip all the files into a new folder somewhere in your
 home folder. IMPORTANT NOTE: The sound font .sf2 files are necessary and
 are in a separate download.

2) Open a Terminal, cd to the new folder you created above and type

 ./install_eplay

 All the files and libraries will then be copied to their necessary
 destinations. If any of the files already exist on your computer a
 backup copy will be made in the destination folder with the
 extension .old

 eplay also needs some system files in /usr/lib these will probably be
 already installed - if so no action is needed. However if one or more
 is missing install_eplay will tell you and you will have to run it again
 with Administrator privileges.

3) Using Finder copy and paste eplayScript2.app into the /Applications directory,
 you will need Administrator privileges. Delete the old eplayScript.app if
 it exists.

4) ctrl click any .m25 e-roll and select "Get Info" a dialog will open. Select
 Open With "Other...", click on eplayScript2.app with the (slightly altered)
 MM icon in the /Applications folder, select "Always Open With" then click on
 "Add". Now select "Change All..." and accept the resulting dialog. All
 .m25 e-rolls will now use eplay to play when you double click them.

 Repeat with any .m50 e-roll again with any .m65 e-roll and again with any
 .mes e-roll.

5) Double click on any e-roll: a window will open the music will play and when
 finished the window will close.

Updating from a previous version:

The simplest way is to follow the First Time Installation as above. Be sure to
install the NEW eplayesteymac sound font files as the old one will not work
with ehe new package.

Sound Quality and Organ Simulation

If you connect a good hi-fi system to your computer the sound will probably be better
than you would get from a real organ, mainly because all notes play with perfect tuning
and there is no mechanical noise.

Note that the Estey sound fonts 201507esteyDB0-0.sf2 and 201507esteyDB1-0.sf2 have not yet
been completed. They already contain good organ sounds and play all of Estey's set combinations
for all Estey rolls up to 1099 but the sounds are not correct for all of the combinations.
Use of two sound fonts will potentially eliminate the New Music incompatibilities but
the fonts need further development.

David Back September 2015.

