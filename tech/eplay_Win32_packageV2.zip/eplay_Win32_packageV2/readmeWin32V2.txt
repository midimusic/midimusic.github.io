EplayWin32 V2.0 February 2016

EplayWin32 will play all Estey e-rolls and can be programmed to play any
Hauptwerk organ. As provided it is set up to play the St. Anne's organ as
this is quite a good match to any small Estey organ. It will also optionally
play the Paramount310 organ. Any other Hauptwerk organ can be played by adding
its data to the provided eplay.ini file.

The Manuals, pedals, stops, couplers and swell all operate as Estey originally
intended.

Output from eplayWin32 is sent to a midi port from whence it will connect
to any Hauptwerk organ via a real or virtual midi cable. Thus the organ can be
running on the same computer as eplayWin32, or on any other computer.

EplayWin32 was produced using Windows 10 but it will work on all versions
of Windows back to and including XP.

Installation

1. Install your Hauptwerk organ. It will operate on a Windows or an iMac
computer. EplayWin32 will play either organ but at present it must
itself run on a Windows computer. You can download and run Hauptwerk along
with the St. Anne's Moseley organ completely free from hauptwerk.com,
it's a large download.

2. Install eplayWin32 (On the Windows computer)

If you have not already done so make the folder c:\eplay. Extract all the files
from the downloaded eplay_Win32_packageV2.zip to this folder. For convenience
I suggest you make a shortcut to eplayWin32.exe and add it to your desktop.
You will see the eplay icon.

3. Connect the output from eplayWin32 to the input of the Hauptwerk organ.

You will need a midi connection between eplayWin32's output and the organ's input.
There are several ways this can be provided:

3.1. If eplayWin32 and Hauptwerk are installed on the same Windows computer:

Install LoopBe1 which is free from www.nerds.de/en/loopbe.html This works well
and I have had no problems with it.

3.2. If eplayWin32 is installed on a Windows computer and Hauptwerk on an iMac:

You can use two cheap hardware usb to midi adaptors connected via a length of midi
cable. Plug one adaptor into the iMac usb port and the other into the Windows usb port
and connect "midi out" from the Windows computer to "midi in" on the iMac.

Alternatively, but not recommended and not described here, you can connect wirelessly
via a midi to ethernet driver on the Windows computer and the built in midi to ethernet
driver on the iMac. Both computers must be connected to the same router.

4. Setup the Hauptwerk MIDI input

Select the Hauptwerk "General Settings" menu and select the
"General Configuration Wizard".

Once in the wizard, do not reset anything unless you need to.

Select MIDI hardware/console: "Assorted MIDI or USB music keyboards/synths"

If the organ is installed on an iMac -
Select USB MIDI Interface: Sequencer MIDI IN (advanced usage).

If the organ is installed on Windows with LoopBe1 -
Select LoopBe Internal MIDI: Sequencer MIDI IN (advanced usage).

Do not change Audio Outputs. Click OK and you are done.

5. Using eplayWin32

Double click eplayWin32.exe or the shortcut on your desktop, eplayWin32 will open
its window. Click on the "Options" menu and select "Setup".

Select the organ you wish to play.

If the organ is installed on an iMac - or any other computer, select your (real)
MIDI cable and click OK

If the organ is installed on the same Windows computer, select LoopBe Internal MIDI
and click OK.

Start the Hauptwerk organ.

To play Estey e-rolls select File/Open, navigate to the e-roll you want to play, select
it and click OK. If all is set up correctly the music roll will play on the organ.

Thats all there is to it - you can now play any Estey e-roll on your Hauptwerk organ.

To get the best out of Hauptwerk you will need to connect a good quality hi-fi amplifier
and speakers. The organ can produce very low notes at high amplitude - just like a real
organ.

6. Notes

If you want to see the black notes moving please complain to Hauptwerk; they know
there is a problem and how to cure it but they will do nothing unless they get
complaints.

You can turn off the organ's blower noise and other noises if you don't want them, refer
to the Hauptwerk user manual.

The Paramount stops I have set up are just a starting point to get it playing. A good
organist will be able to make significant improvements to the sound by making use of
the "Edit Stops" menu. If you come up with a better set of stops please let me know
as I would like to provide them with the eplayWin32 package for other, perhaps less
skilled, users to enjoy.

Please contact me if you require assistance to program eplayWin32 to play other
Hauptwerk organs.

I am planning to add the Miditzer organ to its built-in repertoire in the next version.

David Back February 2016. Contact details are in "About" on my website.
