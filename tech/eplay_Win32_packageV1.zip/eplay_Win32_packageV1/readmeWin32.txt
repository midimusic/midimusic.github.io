EplayWin32 V1.0 January 2016

EplayWin32 will play any estey e-roll on a Hauptwerk organ (St. Anne's Moseley).
The St. Anne's organ is quite a good match to any small Estey organ.
The Manuals, pedals, stops, couplers and swell will all operate as Estey originally
intended.

The output from eplayWin32 is sent to a midi port from whence it will connect
to any Hauptwerk organ via a real or virtual midi cable. Thus the organ can be
running on the same computer as eplayWin32, or on any other computer.

EplayWin32 was produced using Windows 10 but it will work on all versions
of Windows back to and including XP.

Installation

1. Install your Hauptwerk organ. It will operate on a Windows or an iMac
computer. EplayWin32 will play either organ but at present it must
itself run on a Windows computer. You can download and run Hauptwerk along
with the St. Anne's Moseley organ completely free from hauptwerk.com,
it's a large download.

2. Install eplayWin32 (On the Windows computer)

If you have not already done so make the folder c:\eplay. Extract all the files
from the downloaded eplay_Win32_packageV1.zip to this folder. For convenience
I suggest you make a shortcut to eplayWin32.exe and add it to your desktop.
You will see the eplay icon.

3. Connect the output from eplayWin32 to the input of the Hauptwerk organ.

You will need a midi connection between eplayWin32's output and the organ's input.
There are several ways this can be provided:

3.1. If eplayWin32 and Hauptwerk are installed on the same Windows computer:

Install LoopBe1 which is free from www.nerds.de/en/loopbe.html This works well
and I have had no problems with it.

3.2. If eplayWin32 is installed on a Windows computer and Hauptwerk on an iMac:

You can use two cheap hardware usb to midi adaptors connected via a length of midi
cable. Plug one adaptor into the iMac usb port and the other into the Windows usb port
and connect "midi out" from the Windows computer to "midi in" on the iMac.

Alternatively, but not recommended and not described here, you can connect wirelessly
via a midi to ethernet driver on the Windows computer and the built in midi to ethernet
driver on the iMac. Both computers must be connected to the same router.

4. Setup the Hauptwerk MIDI input

Select the Hauptwerk "General Settings" menu and select the
"General Configuration Wizard".

Once in the wizard, do not reset anything unless you need to.

Select MIDI hardware/console: "Assorted MIDI or USB music keyboards/synths"

If the organ is installed on an iMac -
Select USB MIDI Interface: Sequencer MIDI IN (advanced usage).

If the organ is installed on Windows with LoopBe1 -
Select LoopBe Internal MIDI: Sequencer MIDI IN (advanced usage).

Do not change Audio Outputs. Click OK and you are done.

5. Using eplayWin32

Double click eplayWin32.exe or the shortcut on your desktop, eplayWin32 will open
its window. Click on the "File" menu and select "Setup".

If the organ is installed on an iMac - or any other computer, select your (real)
MIDI cable and click OK

If the organ is installed on the same Windows computer, select LoopBe Internal MIDI
and click OK.

Start the Hauptwerk organ.

To play Estey e-rolls select File/Open, navigate to the e-roll you want to play, select
it and click OK. If all is set up correctly the music roll will play on the organ.

Thats all there is to it - you can now play any Estey e-roll on your Hauptwerk organ.

To get the best out of Hauptwerk you will need to connect a good quality hi-fi amplifier
and speakers. The organ can produce very low notes at high amplitude - just like a real
organ.

6. Notes

If you cannot see the black notes moving please complain to Hauptwerk; they know
there is a problem and how to cure it but they will do nothing unless they get
complaints.

You can turn off the organ's blower noise and other noises if you don't want them, refer
to the Hauptwerk user manual.

I am planning to extend eplayWin32 to make the stops user programmable so it will play
Estey e-rolls on other Hauptwerk organs. Please contact me if you would like to have
this or other features (such as the ability to play Wurlitzer e-rolls on Hauptwerk organs).

David Back January 2016.
