How to install eplayOrgan. Version 2_1b

1. IMPORTANT If you have a previous installation of eplayOrgan and
have either altered the stop settings or added other organs you may
wish to save a backup of your eplayOrgan.xml file in a safe place before
uninstalling. Location for Windows:-
c:\Program Files\eplayOrgan\eplayOrgan.xml for 32 bit windows systems or
c:\Program Files (x86)\eplayOrgan\eplayOrgan.xml for 64 bit windows systems.
Location for iMac and Linux (hidden):-
(your home directory)/.wine/c:/Program Files/eplayOrgan/eplayOrgan.xml for 32 bit systems or
(your home directory)/.wine/c:/Program Files (x86)/eplayOrgan/eplayOrgan.xml for 64 bit systems.

2. Install eplayOrgan

2.1. Windows - Run the eplayOrgan setup program setup_eplayOrganV2_1b.exe

2.2. iMac - To run under wine - If necessary first download and install wine.
Run the setup program as for Windows. You may have to specify that the setup
program (in its properties dialog) must be run with Wine.
In order to get a shortcut on your desktop you may have to manually create an alias
of eplayOrgan.exe and copy it to your desktop. Note that the eplayOrgan is
installed  the .wine/c: folder which will be hidden in your home folder.
To run eplayOrgan just double click the .exe or its alias. It will start up and
run just as it does on Windows.

2.3. Linux - Same as iMac above but the desktop shortcut should automatically
install without intervention.

3. OPTIONAL This version of eplayOrgan will not work with previous eplayOrgan.xml
files. You may wish to transfer some of your old backed up eplayOrgan.xml
settings to the new eplayOrgan.xml settings provided with this copy of eplayOrgan.
Be careful mistakes can easily prevent the program functioning correctly. Use
the menus to make changes - not direct editing.

David Back May 2018
