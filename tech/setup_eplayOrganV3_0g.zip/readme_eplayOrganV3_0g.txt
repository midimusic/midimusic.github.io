eplayOrgan V3.0g June 2019

1. General

EplayOrgan is a multi purpose virtual pipe organ intended to
be playable by organists. It will load and be playable almost instantly
and does not need an expensive computer with huge amounts of memory.

Nearly all organs have their own unique midi format. There is no
standardisation for midi channels, stops or expression controls.
Thus an organ midi file will seldom if ever play properly on another organ
and there is never any chance of it playing properly on any normal midi player.

Version 3 and later of eplayOrgan has solved this problem by enabling you
to automatically and in real time translate and play an organ midi file on
another organ. No other organ can do this.

Translation is a two stage process, first the file is translated to an
intermediate, Universal organ format and then translated again to play on the
target organ. You can either record the intermediate file and play it later on
the target organ or you can route it to the target organ via a real or virtual
midi cable for immediate playing. For stops which do not exist on the target
organ a "Virtual Organist" will automatically select alternatives. You can also
adjust stops by hand while your translated organ is being recorded.

The midi file player includes the latest ideas on how to accurately play
a midi file. A multi track midi file has to necessarily have its midi events
sorted into time order before it can be played. This process used to have the
problem that events occuring at exactly the same time could get out of order.
This lack of order sometimes generated "note on" events without any
corresponding "note off" event potentially generating a cipher (continuously
playing note). This used to be avoided by checking that every "note on" event had
a corresponding "note off" event before allowing the note to play. This check
is no longer needed and the result is 100% accurate playing of all midi files
and the improvement is well worthwhile.

Velocity sensitivity may be applied to any rank, or even the entire organ.

You can now export and import organs, this is useful for sharing and adding new
organs. Hauptwerk's sysex format for stop selection is now supported.

Hauptwerk midi file formats are now better supported. Stops may be selected using
midi sysex events as well as nrpn events and master couplers may be used. Both
will be recorded and played, as appropriate, in midi files.

Version 3.0f has cosmetic improvements. A brown textured background has
been introduced and floating point maths are used to create the layout. The pistons
are now coloured.

Version 3.0g is a bug fix version which makes the Swell and Volume inputs work
correctly from the Manual inputs. Any midi "Volume" events output from the keyboards
will be active in setting the Swell level from the Swell Manual and the Volume level
from the Great Manual. This is automatically set up for all organs.

2. Installation

eplayOrgan will install and run on almost any computer using Windows.
It will also install and run correctly on Mac or Linux computers but for this
you will first need to install Wine. See the READMEFIRST.txt file for
installation details.

2.1 Installation on Mac

Recently (as of around October 2018) either Apple or Wine have been tinkering with the
IAC virtual and real midi cable drivers. The result of this is that neither real
nor the built in virtual cables work particularly well with organs. Look out for
lost midi events particularly when a lot of events occur in quick succession.

3. Using eplayOrgan

Double click eplayOrgan.exe or the alias (shortcut) on your desktop,
eplayOrgan will open its window. Click on the "Options" menu and
select "Setup". Select the organ you wish to play.

Use the Help menu for details.

You are likely to need a touch screen monitor for selecting stops
while playing, but your mouse will work at other times. If you plan to
use the "Stops Input" your hardware will need to supply the stops and
expression controls as Universal NRPN's and controls as this enables one
source to be translated and service the needs of all the different organs.

A minimum of one midi keyboard will be needed, midi keyboard channels
are set up automatically. Most midi keyboards will be able to provide the midi
program change messages required to select pistons and control change messages
required to set Swell and Volume levels. If you are a proper
organist you will also need some midified organ pedals and a few other
bits of woodwork to hold it all together. Use midi to USB adaptors to
connect your keyboards and pedals. Try to get your adaptors all from different
makers so that they all have different names. The name is the only means
of identifying one from the other and cannot be altered.

To get the best out of the organs you will need to connect at least
one good quality hi-fi amplifier and speakers. These organs can produce
very low notes at high amplitude - just like a real organ. There are
up to four stereo outputs if you want more realism.

6. Notes

The Burea Church sound font Burea_Church_Ext_2.02.sf2 is associated
with jOrgan and can currently be downloaded from:
http://familjenpalo.se/vpo/sf2

Many other sf2 sound fonts are available and all of them will work
with eplayOrgan, use Viena to edit them if necessary.

EplayOrgan can be played from any midi keyboards or a full midified
organ console. Latency of eplayOrgan is negligable when it is used on
a Windows system but on the iMac and Linux latency may a bit marginal
for comfortable playing from keyboards.

Hundreds of midi files playable on the various organs can be found on
line. As a starting point try the links to websites listed in "Help".
You can also play the e-rolls in my archives by using eplayWin32 and
linking it to eplayOrgan with a virtual midi cable. There are also many
thousands of midified piano rolls available on line. With a bit of work
these can be filtered and edited to play on an organ.

Please contact me if you require assistance to program eplayOrgan
to play other organs. I would also like to hear from you if you get
eplayOrgan working properly on another organ - your experience may be
useful to others. There is now a numerical indication of which stop
is selected. This is useful when designing a new organ.

I would like to hear of any problems found by organists who have
played eplayOrgan. I will cure problems and issue updates as necessary.

David Back June 2019. Contact details are in "About" on my website
https://midimusic.github.io

