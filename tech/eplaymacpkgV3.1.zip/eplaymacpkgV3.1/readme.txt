eplaymac package version 3.1

Installing eplay into an iMac

I believe this package contains all you need to install eplay into
an iMac (i.e. a Mac with a 64 bit Intel processor).

Once the package has been installed you will be able to play any
e-roll anywhere on your system just by double clicking it.

Alternatively you can drag and drop any e-roll on to eplayScript.app
and the roll will play. You will find it on the Launchpad - with its
yellow MM icon. You may find it convenient to add a copy to the Dock
or just copy and paste a copy on to your Desktop.

In both cases a window will open, the music will play and when finished
the window will close.

This package was developed on an iMac using Yosemite operating system.
I suspect it will work on older systems but have not tested it.

Also, as I have access to only the one iMac, which is no longer new,
I cannot check for sure that I have included every library file which
would be needed by a brand new system. If you get an error message
saying eplay needs a library file which is not installed on your system
please email me (email address is in "About Midimusic") and I will send
you the file/s that you need and update the package accordingly.

To install the package:

1) Using Finder unzip all the files into a new folder somewhere in your
 home folder. IMPORTANT NOTE: the necessary sound font .sf2 files are in
 a separate download. Unzip and copy them to the new folder with the
 other files.

2) Open a Terminal, cd to the new folder you created above and type
 ./install_eplay
 All the files and libraries will then be copied to their necessary
 destinations. If any of the files already exist on your computer a
 backup copy will be made in the destination folder with the
 extension .old

 eplay also needs some system files in /usr/lib these will probably be
 already installed - if so no action is needed. However if one or more
 is missing install_eplay will tell you and you will have to run it again
 with Administrator privileges.

3) Using Finder copy and paste eplayScript.app into the /Applications directory,
 you will need Administrator privileges.

4) ctrl click any .m25 e-roll and select "Open with Other..." a dialog will
 open. Click on eplayScript.app with the MM icon - click "Always Open With"
 option and then click the open button. The e-roll will play and so will all
 other e-rolls of that type.

Repeat with any .m50 e-roll again with any .m65 e-roll and again with any
 .mes e-roll.

5) Double click on any e-roll: a window will open the music will play and when
 finished the window will close.

Minor Bug:

1) Two windows open when the music plays. Both close when the music finishes.
 This is annoying but harmless and I will be looking into how it can be cured.

David Back July 2015.
