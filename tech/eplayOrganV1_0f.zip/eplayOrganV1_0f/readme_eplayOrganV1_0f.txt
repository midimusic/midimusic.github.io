eplayOrgan V1.0f March 2018 (Easter Edition)

1. General

EplayOrgan is a brand new multi purpose organ intended to be played by organists. It will
load and be playable almost instantly and does not need an expensive computer with huge
amounts of memory.

This update includes the Burea Church Organ which is compatible with Hauptwerk's Burea
Church Organ.

Reverb is now working correctly and allows you to select from a choice of five preset values
for each organ. You can view the currently selected values on the Audio menu.

You can now select your preferred soundfont bank when there is a choice of more than one bank, as
in Burea Church.

As well as the above improvements, the annoying and unnecessary error message when you start
eplayOrgan with no midi ports installed has been deleted. Also the "Stop" button functionality
when stopping a recording has been improved.

2. Installation

On any computer, Windows, Mac or Linux just copy the files to any folder of your choice.
Make a shortcut to eplayOrgan.exe and put it on your desktop or other menu system
that you use.

For running eplayOrgan on Mac or Linux computers you will need to install Wine.

3. Using eplayOrgan

Double click eplayOrgan.exe or the alias (shortcut) on your desktop, eplayOrgan will open
its window. Click on the "Options" menu and select "Setup". Select the organ you wish to
play.

Use the Help menu for details.

You are likely to need a touch screen monitor for selecting stops while playing, but
your mouse will work at other times. A minimum of one midi keyboard will be needed,
midi keyboard channels are set up automatically. Most midi keyboards will be able to provide
midi program change messages to select pistons. If you are a proper organist you will also
need some midified organ pedals and a few other bits of woodwork to hold it all together.

To get the best out of the organs you will need to connect at least one good quality hi-fi
amplifier and speakers. These organs can produce very low notes at high amplitude - just
like a real organ.

6. Notes

If you want to play the Miditzer organs and do not already have the organs and sound
fonts installed you can download the organs and sound fonts from the Miditzer website. They
are all completely free. The Miditzer organs are intended for and run properly only on Windows
but their sound fonts can be used with eplayOrgan and work on any operating system.

I recommend starting with the Miditzer 216. You may need to edit the eplayOrgan organs and
change the sound font locations from or to
c:\Program Files\Miditzer Style ...... from or to c:\Program Files (x86)\Miditzer Style ......

The Burea Church sound font Burea_Church_Ext_2.02.sf2 is associated with jOrgan and can
currently be downloaded from:
http://familjenpalo.se/vpo/sf2

Many other sf2 sound fonts are available and all of them will work with eplayOrgan, use
Viena to edit them if necessary.

EplayOrgan can be played from any midi keyboards or a full midified organ console.
Latency of eplayOrgan is negligable when it is used on a Windows system but on the iMac and
Linux latency may a bit marginal for comfortable playing from keyboards.

Please contact me if you require assistance to program eplayOrgan to play other organs.

I would like to hear of any problems found by organists who have played eplayOrgan. I will
cure problems and issue updates as necessary.

If eplayOrgan proves successful I will produce native versions for Mac and Linux. All
the basics are already in place and little more than recompilation is needed to do this.

David Back March 26 2018. Contact details are in "About" on my website
https://midimusic.github.io

