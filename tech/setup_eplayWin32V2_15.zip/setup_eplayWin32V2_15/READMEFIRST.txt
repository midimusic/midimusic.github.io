How to install eplayWin32. Version 2.15

1. IMPORTANT If you have a previous installation of eplayWin32 and
have either altered the stop settings or added other organs you may
wish to save a backup of your eplay.ini file in a safe place before
uninstalling. Location:-
c:\Program Files\eplay\eplay.ini for 32 bit windows systems or
c:\Program Files (x86)\eplay\eplay.ini for 64 bit windows systems.
Note: eplayWin32V2.15 will not run with old elpay.ini files.

2. UNINSTALL Use the control panel to uninstall any previous version
of eplayWin32 as the installer will not install a new version over the
top of an old version.

3. SETUP Run setup_eplayWin32V2_15.exe, this will install the new copy.
Alternatively you can simply do a manual install by copying the folder
eplayWin32V2_15 to a location of your choice.

4. OPTIONAL You may wish to transfer some of your old backup settings
to the new settings provided with this copy of eplayWin32. Be careful
mistakes can easily prevent the program functioning correctly. Use the
menus to make changes - not direct editing. You cannot directly use an
old eplay.ini with this version of eplayWin32.

David Back March 2016
