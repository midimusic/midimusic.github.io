EplayWin32V3_1a June 2016, updated October, December 2016.
(Christmas Edition)

EplayWin32V3_1a will play all Estey e-rolls and can be programmed to play any
Hauptwerk, Miditzer, multiOrgan or other organ which has a midi input. As provided
it is set up to play the St. Anne's organ as this is quite a good match to any
small Estey organ.

It will also play the Paramount 310, an Estey Church organ and several Miditzer
organs. Almost any other organ can be played by using the options menu to add
appropriate organ and stop data.

The Manuals, pedals, stops, couplers and swell all operate as Estey originally
intended.

EplayWin32V3 will also play all Wurlitzer Band Organ Rolls on multiOrgan using
Rich Olsens Band Organ sound fonts which are widely acknowledged to be the best
available. All stops and shutters are fully activated.

Output from eplayWin32 is sent to a midi port from whence it will connect
to Hauptwerk, Miditzer, multiOrgan or other organ via a real or virtual midi cable.
Thus the organ can be running on the same computer as eplayWin32, or on any
other computer.

EplayWin32 was produced using Windows 10 but it will work on all versions
of Windows back to and including XP. Note that some old computers running old
versions of windows may not be fast enough or have enough memory to run
these programs.

This version will also work correctly under Wine when installed on an iMac
or most Linux systems.

Version 3_1 has been designed so that multiple instances of eplayWin32 will
operate together and can be controlled from just one of the instances. If you
setup the instances to start on "Play/Pause" instead of the default "Immediately"
you can load each instance with a tune and when you press "Play" they will all
start playing together. "Pause", "Continue" and "Stop" also work in synchronysm.

Version 3_1a corrects minor bugs in the NRPN generator which do not affect Hauptwerk
but may affect other organs. It also includes several .cmb settings files which
when imported into GrandOrgue will allow eplayWin32 to play the matching
sampleset on GrandOrgue.

If each instance of eplayWin32 is installed in its own folder (best copy the file
sets by hand) you can set up each instance differently. Thus you can play two or
more different organs at the same time. The Latency Delay can be used to cancel
any difference of latency between the organs. Thus you could, for example, play
multiOrgan and Hauptwerk and/or Miditzer and/or GrangOrgue organs all at the
same time.

There are also a few other minor improvements.

Installation

1. Install your Hauptwerk organ. It will operate on a Windows or an iMac
computer. EplayWin32 will play either organ. You can download and run
Hauptwerk along with the St. Anne's Moseley organ completely free from
hauptwerk.com, it's a large download.

Alternatively or additionally you can download and run a Miditzer 216 organ.
This runs on Windows and is completely free. It is a much smaller download
than Hauptwerk. Other Miditzer organs will also work.

If you want to play Wurlitzer Band Organ rolls you will need to install my
multiOrgan program. This will simulate almost any organ and can play all the
music rolls in my archives.

2. Install eplayWin32

2.1. Windows - Run the eplay setup program setup_eplayWin32V3_0.exe
Alternatively you can simply do a manual install by copying the folder
eplayWin32 and its files to a location of your choice.

2.2. iMac - To run under Wine - If necessary download and install Wine.
Copy the folder eplayWin32 and its files to a location of your choice.
You can make an alias (shortcut) of eplayWin32.exe and keep it on your desktop.
To run eplayWin32 just double click the .exe or its alias. It will start up and
run just as it does on Windows.

2.3. Linux - Same as iMac above or you can use setup_eplayWin32V3_0.exe to
install.

3. Connect the output from eplayWin32 to the input of the Hauptwerk, Miditzer,
multiOrgan or GrandOrgue organ.

You will need a midi connection between eplayWin32's output and the organ's input.
There are several ways this can be provided:

3.1. If eplayWin32 and Hauptwerk, Miditzer, multiOrgan or GrandOrgue are installed
on the same computer:

Use a virtual midi cable, the iMac has one built in, it's called IAC driver. Use the
Audio MIDI setup.app to enable it. The cable is called Bus 1.
Note: if you are connecting to multiOrgan or any other organ running under Wine on
an iMac you will need a real midi cable, see 3.2 below. This is because the Wine midi
input port on the iMac has a severe bug which prevents it from working properly with
organs -- this bug appears to be cured in OSX Sierra.

For Windows you can download and install loopBe1 or one of the many others.

For Linux you will probably find a virtual cable already built in. If there is one it
will usually show in the eplayWin32 setup menu as "Midi Through Port-0". If not you
may have to download and install one.

3.2. If eplayWin32 and Hauptwerk, Miditzer, multiOrgan or GrandOrgue are installed
on different computers:

You can use two cheap hardware usb to midi adaptors connected via a female to
female midi adaptor. Plug one midi adaptor into an a usb port on one computer and
the other midi adaptor into a usb port on the other computer. Using the female to
female midi adaptor, connect "midi out" from the computer with eplayWin32 to
"midi in" on the computer with the organ.

4. Setup the Hauptwerk MIDI input

Select the Hauptwerk "General Settings" menu and select the
"General Configuration Wizard".

Once in the wizard, do not reset anything unless you need to.
Select MIDI hardware/console: "Assorted MIDI or USB music keyboards/synths"
At sequencer MIDI IN (advanced usage) - select the name of your <virtual midi cable>
or <real MIDI cable>.
Do not change Audio Outputs. Click OK and you are done.

5. Setup the Miditzer MIDI input

Using the "M" menu (in the top left hand corner) Select Miditzer Settings...
Select Input and add the name of your <virtual midi cable> or <real MIDI cable> to the Active
MIDI input devices. ***IMPORTANT***: Select Pistons and select Enable Midi Panic. Do not
alter anything else. Select OK.

6. Setup the multiOrgan MIDI input

Using the Options/Setup... menu select the midi port and the organ you wish to use.

7. Setup GrandOrgue MIDI input (using GrandOrgue demo V1 sampleset)

Ensure that GrandOrgue has the GrandOrgue demo V1 sampleset installed and running.

Using the Audio/Midi menu select Audi/Midi Settings > MIDI Devices > MIDI input devices
and select your real or virtual midi input cable. Select OK.

Select File > Import Settings and browse to the folder where eplayWin32 is installed. Select
GO-eplayWin32-demoV1.cmb and click OK.

WARNING: Grand Orgue will not play correctly with the default Samples per Buffer value
of 1024. Change Audio/Midi > Audi/Midi Settings > Samples per Buffer to 128. Select OK.

Select File > Save to save all the above settings.

8. Using eplayWin32

Double click eplayWin32.exe or the alias (shortcut) on your desktop, eplayWin32 will open
its window. Click on the "Options" menu and select "Setup".

Select the organ you wish to play.

If the organ is installed on the same computer, select your virtual MIDI cable and click OK.

If the organ is installed on another computer, select your real MIDI cable and click OK

Start the Hauptwerk,  Miditzer, multiOrgan or GrandOrgue organ.

To play Estey or Wurlitzer e-rolls select File/Open, navigate to the e-roll you want to
play, select it and click OK. If all is set up correctly the music roll will play on the organ.
Alternatively you can drag and drop any Estey or Wurlitzer Band Organ e-roll on to
eplayWin32 and it will begin playing.

Thats all there is to it - you can now play any Estey e-roll on your Hauptwerk,
Miditzer, multiOrgan or GrandOrgue organ and any Wurlitzer Band Organ roll on multiOrgan.

When using multiOrgan you have a choice of organs to play and it is important to select
an appropriate organ. You cannot play Estey rolls on a Band Organ.

To get the best out of the organs you will need to connect a good quality hi-fi amplifier
and speakers. These organs can produce very low notes at high amplitude - just like a real
organ.

9. Notes

If you want to see the black notes moving on the Hauptwerk organ please complain to
Hauptwerk; they know there is a problem and how to cure it but they will do nothing
unless they get complaints.

You can turn off the Hauptwerk and GrandOrgue's blower noise and other noises if you
don't want them, refer to the Hauptwerk user manual or GrandOrgue Help.

The Paramount stops I have set up are just a starting point to get it playing.
A good organist will be able to make significant improvements to the sound by making use
of the "Edit Stops" menu.

Wurlitzer Band organs do not use preset combinations and so their stops settings are
not adjustable.

Please contact me if you require assistance to program eplayWin32 to play other organs.

David Back July 2016. Contact details are in "About" on my website.
