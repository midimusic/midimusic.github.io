eplay_package_v1

This package will play the wurlitzer e-rolls for style 125, 150 and 165 organs
in my Wurlitzer e-roll archive. The organs are fully instrumented and activated
so stops, shutters and bells are all fully functional.

You must use the appropriate .exe file for each organ style. They work only in
a Windows DOS command window, i.e there are no fancy graphics.

Use eplay125 for style 125 e-rolls.
Use eplay150 for style 150 e-rolls.
Use eplay165 for style 165 e-rolls.

This 32 bit package will work on 32 or 64 bit Windows operating systems.
It was designed and tested on Windows 8.1 but should also work
on earlier versions.

To install the package simply copy all the files to a folder of your choice,
ideally a folder on your PATH.

As I am still developing this package and hope eventually to produce a set
of purpose designed patches, you will have to make do with "freepats" for
the time being. The programs will work with any patches is GUS .pat format.

At the present time the sound quality leaves a lot to be desired and is not
as good as that produced by Windows when playing normal midi files. This
is due to deficiencies in freepats which are well documented as not being the
best available.

David Back January 2015.




