readme.txt
Wurlitzer Band Organ e-roll package.

Supplied by: David Back June 2013 (Updated November 2103)

This package was obtained from and is a supplement to my web site page
 http://www.midimusic.org.uk/tech/rollscan.html

The package  helps to show how easy it is to utilise Band Organ
e-rolls for a multitude of purposes and that the e-roll is an ideal
format for archiving Band Organ Rolls.

Archived e-rolls will directly play just as well (or usually better) than
Wurlitzer Paper music rolls on a suitably converted band organ.

Conversion filters supplied:

w125
manana-e.rpl will convert manana0.mid to a w125 e-roll with base 24
fw125e-p.rpl is a filter to convert any w125 e-roll to a w125 playable midi
fw125e-j.rpl is a filter to convert any w125 e-roll to play on Glen Jedlicka's
             e-valve organ

w150
sanjos-e.rpl will convert sanjos0.mid to a w150 e-roll with base 24
fw150e-p.rpl is a filter to convert any w150 e-roll to a w150 playable midi

w165
150-165e.rpl will convert SJ150-E.MID to a w165 e-roll with base 24
fw165-e-p.rpl is a filter which will convert any w165 e-roll to a w165 playable midi

e-rolls

The e-rolls produced will play directly on any Band Organ fitted with e-valves and with
suitably programmed midi hardware and software.

Playable midis

The playable midis are all instrumented with the midi default patch (piano) and are
intended to play on any standard midi player. You will have to adjust the tempo to your
liking. The files are not intended to sound anything like band organs. They should play
directly on Michael Baronsek's instrument.

If you want a band organ sound you will have to edit in appropriate
pipe ranks, channels and patches. Each organ pipe division is already in a separate midi
channel which makes a good starting point for instrumenting the file with midi patches.

midirepl.exe

All of the conversion filters above are data files for midirepl.

midirepl.exe is a very old but still useful DOS program which cannot cope with long
filenames as are routinely used today. Filename must be in 8.3 format which means a
maximum of 8 characters followed by a 3 character extension. midirepl.exe also cannot
copy any track or channel to make a duplicate track or channel within the midi file.

If someone were to get hold of the source of midirepl.exe and update it they would be
doing a great service.

midirepl.zip can be easily downloaded from the internet. I have not included a copy here
because the program is restricted from distribution by several pages of semi-legal
gobbledegook. I can send a known good copy of it to anyone who has a genuine need.

You must take my package as you find it. It is not guaranteed to be error free.

My package is dedicated to the public domain and may be used for any purpose you like.

David Back.

