Eplayesteyh V1.0 December 2015 (More detail added: 17/12/15)

Eplayesteyh will play any estey e-roll on a Hauptwerk organ (St. Anne's Moseley).
The St. Anne's organ is quite a good match to any small Estey organ.
The Manuals, pedals, stops, couplers and swell will all operate as Estey originally
intended.

The output from eplayesteyh is sent to a midi port from whence it will connect
to any Hauptwerk organ via a real or virtual midi cable. Thus the organ can be
running on the same computer as eplayesteyh, or any other computer.

Eplayesteyh was produced using Windows 10 but it will work on all versions
of Windows back to XP.

Installation

1. Install your Hauptwerk organ. It will operate on a Windows or an iMac
computer. Eplayesteyh will play either organ but at present it must
itself run on a Windows computer. You can download and run Hauptwerk along
with the St. Anne's Moseley organ completely free from hauptwerk.com,
it's a large download.

2. Install eplayesteyh (On the Windows computer)

If you have not already downloaded and installed my Windows eplay package now is
the time to do it. Follow the instructions to create the c:\eplay folder and put
it on your "path". This provides the folder and the additional library files needed
by eplayesteyh.

To install eplayesteyh simply extract it and this readme from the .zip to your
c:\eplay folder.

3. Connect the output from eplayesteyh to the input of the Hauptwerk organ.

You will need a midi connection between eplayestey's output and the organ's input.
There are several ways this can be provided:

3.1. If eplayesteyh and Hauptwerk are installed on the same Windows computer:

Install LoopBe1 which is free from www.nerds.de/en/loopbe.html This works well
and I have had no problems with it.

3.2. If eplayesteyh is installed on a Windows computer and Hauptwerk on an iMac:

You can use two cheap hardware usb to midi adaptors connected via a length of midi
cable. Plug one adaptor into an iMac usb port and the other into a Windows usb port
and connect "midi out" from the Windows computer to "midi in" on the iMac.

Alternatively, but not recommended and not described here, you can connect wirelessly
via a midi to ethernet driver on the Windows computer and the built in midi to ethernet
driver on the iMac. Both computers must be connected to the same router.

4. Setup the Hauptwerk MIDI input

Select the Hauptwerk "General Settings" menu and select the
"General Configuration Wizard".

Once in the wizard, do not reset anything unless you need to.

Select MIDI hardware/console: "Assorted MIDI or USB music keyboards/synths"

If the organ is installed on an iMac -
Select USB MIDI Interface: Sequencer MIDI IN (advanced usage).

If the organ is installed on Windows with LoopBe1 -
Select LoopBe Internal MIDI: Sequencer MIDI IN (advanced usage).

Do not change Audio Outputs. Click OK and you are done.

5. Using eplayesteyh

To play an e-roll, open a command window and type  eplayesteyh  followed by a space,
you can then drag and drop any estey e-roll on to the command window and type
a carriage return. Eplayesteyh will run. It will show a list of your midi ports, select
LoopBe Internal MIDI, and if all is set up correctly the music roll will play on the organ.

Thats all there is to it - you can now play any estey e-roll on your Hauptwerk organ.

To get the best out of Hauptwerk you will need to connect a good quality hi-fi amplifier
and speakers. The organ can produce very low notes at high amplitude - just like a real
organ.

David Back December 2015.
