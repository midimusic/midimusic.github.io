How to install eplayWin32.

1. IMPORTANT If you have a previous installation of eplayWin32 and
have either altered the stop settings or added other organs you will
need to save a backup of your eplay.ini file in a safe place.
(See 4. below for its likely location).

2. UNINSTALL Use the control panel to uninstall any previous version
of eplayWin32 as the installer will not install a new version over the
top of an old version.

3. SETUP Run setup_eplayWin32.exe, this will install the new copy.

4. OPTIONAL Copy your backup of eplay.ini to the new installation.
If you have used the default location this will be in
c:\Program Files\eplay for 32 bit windows systems or
c:\Program Files (x86)\eplay for 64 bit windows systems.

David Back February 2016
