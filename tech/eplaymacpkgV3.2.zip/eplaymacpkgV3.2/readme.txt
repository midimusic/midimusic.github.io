eplaymac package version 3.2

Installing eplay into an iMac

See below if you are updating from version 3.1

I believe this package contains all you need to install eplay into
an iMac (i.e. a Mac with a 64 bit Intel processor).

Once the package has been installed you will be able to play any
e-roll anywhere on your system just by double clicking it.

Alternatively you can drag and drop any e-roll on to eplayScript2.app
and the e-roll will play. You will find it on the Launchpad - with its
yellow MM icon. You may find it convenient to add a copy to the Dock
or just copy and paste a copy on to your Desktop.

In both cases a window will open, the music will play and when finished
the window will close.

This package was developed on an iMac using Yosemite operating system.
I suspect it will work on older systems but have not tested it.

Also, as I have access to only the one iMac, which is no longer new,
I cannot check for sure that I have included every library file which
would be needed by a brand new system. If you get an error message
saying eplay needs a library file which is not installed on your system
please email me (email address is in "About Midimusic") and I will send
you the file/s that you need and update the package accordingly.

To install the package:

1) Using Finder unzip all the files into a new folder somewhere in your
 home folder. IMPORTANT NOTE: The sound font .sf2 files are necessary and
 are in a separate download.

2) Open a Terminal, cd to the new folder you created above and type

 ./install_eplay

 All the files and libraries will then be copied to their necessary
 destinations. If any of the files already exist on your computer a
 backup copy will be made in the destination folder with the
 extension .old

 eplay also needs some system files in /usr/lib these will probably be
 already installed - if so no action is needed. However if one or more
 is missing install_eplay will tell you and you will have to run it again
 with Administrator privileges.

3) Using Finder copy and paste eplayScript2.app into the /Applications directory,
 you will need Administrator privileges. Delete the old eplayScript.app if
 it exists.

4) ctrl click any .m25 e-roll and select "Get Info" a dialog will open. Select
 Open With "Other...", click on eplayScript2.app with the (slightly altered)
 MM icon in the /Applications folder, select "Always Open With" then click on
 "Add". Now select "Change All..." and accept the resulting dialog. All
 .m25 e-rolls will now use eplay to play when you double click them.

 Repeat with any .m50 e-roll again with any .m65 e-roll and again with any
 .mes e-roll.

5) Double click on any e-roll: a window will open the music will play and when
 finished the window will close.

Updating from eplaymac package version 3.1:

 The only change in this update is the new eplayScript2.app which now works
 correctly and replaces the old eplayScript.app so you need do only steps 3),
 4), and 5). NOTE: step 4) has also been updated and now works correctly.

Sound Quality and Organ Simulation

If you connect a good hi-fi system to your computer the sound will probably be better
than you would get from a real organ, mainly because all notes play with perfect tuning
and there is no mechanical noise.

Note that the Estey sound font 201507esteyDB-0.sf2 has not yet been completed. It contains
good organ sounds and plays all of Estey's set combinations for Estey rolls up to 1099 but
the sounds are not correct for all of the combinations. This is because I have only recently
discovered what pipe ranks an Estey Player Organ contained and there is signifcant
incompatability between the combinations required for the various stages of Estey's
"New Music" which have not yet been resolved.

David Back July/August 2015.
