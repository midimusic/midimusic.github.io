eplayOrgan V2.2 June 2018

1. General

EplayOrgan is a brand new multi purpose organ intended to be played
by organists. It will load and be playable almost instantly and does
not need an expensive computer with huge amounts of memory.

This update includes the Burea Church Organ which is compatible with
Hauptwerk's Burea Church Organ.

Reverb is now working correctly and allows you to select from a
choice of five preset values for each organ. You can view the
currently selected values in the Audio menu.

You can now select your preferred soundfont bank when there is a
choice of more than one bank, as in Burea Church.

The annoying and unnecessary error message when you start eplayOrgan
with no midi ports installed has been deleted. Also the "Stop" button
functionality when stopping a recording has been improved.

Version 2.0 has had the midi file player internally improved to include
the latest ideas on how to accurately play a midi file. A multi track
midi file has to necessarily have its midi events sorted into time order
before it can be played. This process used to have the problem that events
occuring at exactly the same time could get out of order. This lack of order
sometimes (but rarely) generated "note on" events without any corresponding
"note off" event potentially generating a cipher (continuously playing note).
This used to be avoided by checking that every "note on" event had a
corresponding "note off" event before allowing the note to play.

The result of this was that occasionally notes which should play did not
play - usually unnoticed by the listener.

The new sorting algorithm employed in version 2.0 avoids this problem
and the mechanism for not playing unmatched notes has been removed from
eplayOrgan. The result is 100% accurate playing of all midi files and
the improvement is well worthwhile.

Version 2.1 has all the improvements above plus the addition of a playlist
for each organ. You can add whatever tunes you like to these lists and
they will play either continuously on a loop or once from top to bottom
of the lists. The playlist can be hidden whilst the music is playing.

None of the well known organs, Miditzer, Hauptwerk, Grandorgue etc. have
built in playlists; eplayOrgan is the ONLY one with this feature.
You can now record your organ recital in easy steps and play the whole
thing in one go using a playlist.

Version 2.1a: The only change is the addition of Bruce Miles Cinema Organ
sound font which gives stereophonic sound in place of the previoulsy suggested
fonts which were monophonic. A great improvement.

Version 2.1b: Addition of "default" audio output to make setting up audio
outputs automatic for the simplest option of only one output.
Minor improvements to corg_w111m900.sf2, now renamed corg_w111m901.sf2

Version 2.1c: This is a bugfix version. The screen keyboards now display the
topmost C correctly. The "Failed to Load Pedal Soundfont" problem is fixed.
(It is possible on some systems it may re-appear -- if so you can cure it
by entering the full path and filename of each sound font into Options/Edit Organ..)
The fluidsynth Log is now implemented -- if there is a problem you will get
full diagnostic messages on the screen.

Version 2.1d: As well as all the above improvements the stops can now be "swiped" on
or off and the manuals have a fully chromatic "swipe". Thus both are easier to use
and manage. When recording, the results of a general clear are now recorded along
with all the other midi events. Thus all the stops will be cleared at the end of a
recording if you press general clear before stopping. Minor errors in Viscount
Regent stop assignments are fixed. Additional information has been added to the
help file.

Version 2.2: Colour has been added to all of the stops and their order has been
rearranged for all organs. The stops are now as near as practical in their normal
order for playing and can be swiped just like the original organs. Minor bugs in
the manuals have been fixed. Help file updated.

2. Installation

For running eplayOrgan on Mac or Linux computers you will first need
to install Wine. See the READMEFIRST.txt file for installation details.

3. Using eplayOrgan

Double click eplayOrgan.exe or the alias (shortcut) on your desktop,
eplayOrgan will open its window. Click on the "Options" menu and
select "Setup". Select the organ you wish to play.

Use the Help menu for details.

You are likely to need a touch screen monitor for selecting stops
while playing, but your mouse will work at other times. A minimum
of one midi keyboard will be needed, midi keyboard channels are set
up automatically. Most midi keyboards will be able to provide the midi
program change messages required to select pistons. If you are a proper
organist you will also need some midified organ pedals and a few other
bits of woodwork to hold it all together.

To get the best out of the organs you will need to connect at least
one good quality hi-fi amplifier and speakers. These organs can produce
very low notes at high amplitude - just like a real organ. There are
up to four stereo outputs if you want more realism.

6. Notes

The Burea Church sound font Burea_Church_Ext_2.02.sf2 is associated
with jOrgan and can currently be downloaded from:
http://familjenpalo.se/vpo/sf2

Many other sf2 sound fonts are available and all of them will work
with eplayOrgan, use Viena to edit them if necessary.

EplayOrgan can be played from any midi keyboards or a full midified
organ console. Latency of eplayOrgan is negligable when it is used on
a Windows system but on the iMac and Linux latency may a bit marginal
for comfortable playing from keyboards.

Please contact me if you require assistance to program eplayOrgan
to play other organs.

I would like to hear of any problems found by organists who have
played eplayOrgan. I will cure problems and issue updates as necessary.

David Back June 2018. Contact details are in "About" on my website
https://midimusic.github.io

