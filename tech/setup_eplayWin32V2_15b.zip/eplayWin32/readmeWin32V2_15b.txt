EplayWin32V2_15b February 2016. Updated 13, 17, 25 Feb and 5, 15, 25 March 2016.

EplayWin32 will play all Estey e-rolls and can be programmed to play any
Hauptwerk, Miditzer or other organ which has a midi input. As provided it
is set up to play the St. Anne's organ as this is quite a good match to any
small Estey organ.

It will also play the Paramount 310 and several Miditzer organs. Almost any other
organ can be played by using the options menu to add appropriate organ and stop data.

The Manuals, pedals, stops, couplers and swell all operate as Estey originally
intended.

Output from eplayWin32 is sent to a midi port from whence it will connect
to any Hauptwerk, Miditzer or other organ via a real or virtual midi cable.
Thus the organ can be running on the same computer as eplayWin32, or on any
other computer.

EplayWin32 was produced using Windows 10 but it will work on all versions
of Windows back to and including XP. Note that some old computers running old
versions of windows may not be fast enough or have enough memory to run
these programs.

This version will also work correctly under wine when installed on an iMac.

You cannot directly use versions of eplay.ini prior to V2.15 with this version
of eplayWin32.

Installation

1. Install your Hauptwerk organ. It will operate on a Windows or an iMac
computer. EplayWin32 will play either organ. You can download and run
Hauptwerk along with the St. Anne's Moseley organ completely free from
hauptwerk.com, it's a large download.

Alternatively or additionally you can download and run a Miditzer 216 organ.
This runs on Windows and is completely free. It is a much smaller download
than Hauptwerk. Other Miditzer organs will also work.

2. Install eplayWin32

2.1. Windows - Run the eplay setup program setup_eplayWin32V2_15.exe
Alternatively you can simply do a manual install by copying the folder
eplayWin32 and its files to a location of your choice.

2.2. iMac - To run under wine - If necessary download and install wine.
Copy the folder eplayWin32 and its files to a location of your choice.
You can make an alias (shortcut) of eplayWin32.exe and keep it on your desktop.
To run eplayWin32 just double click the .exe or its alias. It will start up and
run just as it does on Windows.

3. Connect the output from eplayWin32 to the input of the Hauptwerk or Miditzer
organ.

You will need a midi connection between eplayWin32's output and the organ's input.
There are several ways this can be provided:

3.1. If eplayWin32 and Hauptwerk or Miditzer are installed on the same computer:

Use a virtual midi cable, the iMac has one built in, it's called IAC driver. Use the
Audio MIDI setup.app to enable it. The cable is called Bus 1. For Windows you can
download and install loopBe1 or one of the many others.

3.2. If eplayWin32 is installed on a Windows computer and Hauptwerk on an iMac:

You can use two cheap hardware usb to midi adaptors connected via a female to
female midi adaptor. Plug one adaptor into an iMac usb port and the other into a Windows
usb port and connect "midi out" from the Windows computer to "midi in" on the iMac.

Alternatively, but not recommended and not described here, you can connect wirelessly
via a midi to ethernet driver on the Windows computer and the built in midi to ethernet
driver on the iMac. Both computers must be connected to the same router.

4. Setup the Hauptwerk MIDI input

Select the Hauptwerk "General Settings" menu and select the
"General Configuration Wizard".

Once in the wizard, do not reset anything unless you need to.
Select MIDI hardware/console: "Assorted MIDI or USB music keyboards/synths"
At sequencer MIDI IN (advanced usage) - select the name of your <virtual midi cable>
or <real MIDI cable>.
Do not change Audio Outputs. Click OK and you are done.

5. Setup the Miditzer MIDI input

Using the "M" menu (in the top left hand corner) Select Miditzer Settings...
Select Input and add the name of your <virtual midi cable> or <real MIDI cable> to the Active
MIDI input devices. ***IMPORTANT***: Select Pistons and select Enable Midi Panic. Do not
alter anything else. Select OK.

6. Using eplayWin32

Double click eplayWin32.exe or the alias (shortcut) on your desktop, eplayWin32 will open
its window. Click on the "Options" menu and select "Setup".

Select the organ you wish to play.

If the organ is installed on the same computer, select your virtual MIDI cable and click OK.

If the organ is installed on another computer, select your real MIDI cable and click OK

Start the Hauptwerk or Miditzer organ.

To play Estey e-rolls select File/Open, navigate to the e-roll you want to play, select
it and click OK. If all is set up correctly the music roll will play on the organ.
Alternatively you can drag and drop any Estey e-roll on to eplayWin32 and it will
begin playing.

Thats all there is to it - you can now play any Estey e-roll on your Hauptwerk or
Miditzer organ.

To get the best out of the organs you will need to connect a good quality hi-fi amplifier
and speakers. These organs can produce very low notes at high amplitude - just like a real
organ.

6. Notes

If you want to see the black notes moving on the Hauptwerk organ please complain to
Hauptwerk; they know there is a problem and how to cure it but they will do nothing
unless they get complaints.

You can turn off the Hauptwerk organ's blower noise and other noises if you don't want
them, refer to the Hauptwerk user manual.

The Paramount stops I have set up are just a starting point to get it playing.
A good organist will be able to make significant improvements to the sound by making use of
the "Edit Stops" menu. If you come up with a better set of stops please let me know
as I would like to provide them with the eplayWin32 package for other, perhaps less
skilled, users to enjoy. I will be making my own improvements to all of the stop settings
as I get time and gain experience.

Please contact me if you require assistance to program eplayWin32 to play other organs.

David Back March 2016. Contact details are in "About" on my website.
