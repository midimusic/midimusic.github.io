There is an error in the stops for eplayOrgan's Miditzer 260.

To get Poet and Peasant to play correctly you need to do the following:

1: start eplayOrgan v2.2b or earlier.

2: Options/Setup, select Miditzer 260 Theatre Organ, OK

3: Options/Map Stops, 2 Great column

4: Change "Chime" from 104 to 113

5: Change "Bells" from 113 to 104

6: Select OK

This will update the eplayOrgan.xml file.